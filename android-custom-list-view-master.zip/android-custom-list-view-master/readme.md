# Android Custom List View

Android custom list view with text and image

![](https://www.asifszone.com/wp-content/uploads/2018/09/Screenshot_20180915-1537281-e1537005133980.png)

## How to use ?
First copy the line given below and clone the repository.Then compile and run :)

```
git clone https://github.com/tanvirasifkhan/Android-Custom-List-View.git

```
## Thanks
